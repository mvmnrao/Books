using System;
using System.Text;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using DomainObjects;
using NHibernate;
using TestSuite.FakeRepository; 

namespace TestSuite
{
   
    [TestClass]
    public class ExamFixture : BaseFixture
    {
        public ExamFixture()
        {
           
        }

        #region Additional test attributes
        //
        // You can use the following additional attributes as you write your tests:
        //
        // Use ClassInitialize to run code before running the first test in the class
        // [ClassInitialize()]
        // public static void MyClassInitialize(TestContext testContext) { }
        //
        // Use ClassCleanup to run code after all tests in a class have run
        // [ClassCleanup()]
        // public static void MyClassCleanup() { }
        //
        // Use TestInitialize to run code before running each test 
        // [TestInitialize()]
        // public void MyTestInitialize() { }
        //
        // Use TestCleanup to run code after each test has run
        // [TestCleanup()]
        // public void MyTestCleanup() { }
        //
        #endregion


        

        [TestMethod]        
        public void CanSaveExamWithMultipleQuestions()
        {
            Exam exam = FakeExamRepository.GetExam();
            List<Question> questions = FakeQuestionRepository.GetQuestions();

          
            foreach (Question question in questions)
            {
                exam.AddQuestion(question); 
            }

            using (ISession session = _sessionFactory.OpenSession())
            {
                using (ITransaction transaction = session.BeginTransaction())
                {
                    session.SaveOrUpdate(exam);
                    session.Flush();
                    session.Evict(exam);

                    Exam eVerify = session.Get<Exam>(exam.Id);

                    Assert.IsTrue(eVerify.Id != 0);

                    Assert.AreEqual(eVerify.Title, exam.Title);

                    Assert.AreEqual(eVerify.Questions.Count, exam.Questions.Count);

                    for(int i=0; i<eVerify.Questions.Count; i++) 
                    {
                        Assert.AreEqual(eVerify.Questions[i].Text, exam.Questions[i].Text);
                        Assert.AreEqual(eVerify.Questions[i].Point, exam.Questions[i].Point); 
                    }                    
                }
            }

        }

        [TestMethod]
       
        public void CanSaveExamWithSingleQuestion()
        {
            Exam exam = FakeExamRepository.GetExam();
            Question question = FakeQuestionRepository.GetQuestion();

            exam.AddQuestion(question);

            using (ISession session = _sessionFactory.OpenSession())
            {
                using (ITransaction transaction = session.BeginTransaction())
                {
                    session.SaveOrUpdate(exam);
                    session.Flush();
                    session.Evict(exam);

                    Exam eVerify = session.Get<Exam>(exam.Id);
                    Assert.IsTrue(eVerify.Id != 0);

                    Assert.AreEqual(eVerify.Title, exam.Title);
                    Assert.AreEqual(eVerify.Questions[0].Text, exam.Questions[0].Text);
                    Assert.AreEqual(eVerify.Questions[0].Point, exam.Questions[0].Point); 
                }
            }

        }

        [TestMethod]
        
        public void CanDeleteExam()
        {
            // get the fake exam
            Exam exam = FakeExamRepository.GetExam(); 
                        
            using (ISession session = _sessionFactory.OpenSession())
            {
                using (ITransaction transaction = session.BeginTransaction())
                {
                    session.SaveOrUpdate(exam);
                    session.Flush();
                    session.Evict(exam);

                    Exam eVerify = session.Get<Exam>(exam.Id);
                    Assert.IsTrue(eVerify.Id != 0);

                    Assert.AreEqual(eVerify.Title, exam.Title);

                    session.Delete(eVerify);
                    session.Flush();
                    session.Evict(eVerify);

                    Assert.IsNull(session.Get<Exam>(eVerify.Id)); 

                }
            }
        }

        [TestMethod]
        
        public void CanAddExam()
        {
            Exam exam = FakeExamRepository.GetExam(); 

            using (ISession session = _sessionFactory.OpenSession())
            {
                using (ITransaction transaction = session.BeginTransaction())
                {
                    session.SaveOrUpdate(exam);
                    session.Flush();
                    session.Evict(exam);

                    Exam eVerify = session.Get<Exam>(exam.Id);
                    Assert.IsTrue(eVerify.Id != 0);

                    Assert.AreEqual(eVerify.Title, exam.Title); 
                }
            }
        }
    }
}
