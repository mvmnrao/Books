using System;
using System.Collections.Generic;
using System.Text;
using DomainObjects;

namespace TestSuite.FakeRepository
{
    public class FakeExamRepository
    {
        public static Exam GetExam()
        {
            Exam exam = new Exam();
            exam.Title = "Exam 1";
            return exam; 
        }
    }
}
