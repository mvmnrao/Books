using System;
using System.Collections.Generic;
using System.Text;
using DomainObjects;

namespace TestSuite.FakeRepository
{
    public class FakeQuestionRepository
    {
        public static Question GetQuestion()
        {
            Question question = new Question();
            question.Text = "What is 2+2?";
            question.Point = 10;
            return question; 
        }

        public static List<Question> GetQuestions()
        {
            List<Question> questions = new List<Question>();
            questions.Add(new Question("What is 2+2?", 10));
            questions.Add(new Question("What is 1+1?", 10));
            questions.Add(new Question("What is 3+3?", 10));
            
            return questions;
        }
    }
}
