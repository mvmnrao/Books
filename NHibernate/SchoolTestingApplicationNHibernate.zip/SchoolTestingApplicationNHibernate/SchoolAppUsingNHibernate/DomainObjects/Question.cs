using System;
using System.Collections.Generic;
using System.Text;

namespace DomainObjects
{
    public class Question
    {
        private int _id;
        private string _text;
        private double _point;
        private Exam _exam = new Exam();


        public Question() { }

        public Question(Exam exam)
        {
            _exam = exam; 
        }

        public Question(string text, double point)
        {
            _text = text;
            _point = point; 
        }

        public int Id
        {
            get { return _id; } 
        }

        public string Text
        {
            get { return _text; }
            set { _text = value; }
        }

        public double Point
        {
            get { return _point; }
            set { _point = value; }
        }

        public Exam Exam
        {
            get { return _exam; }
            set { _exam = value; } 
        }

    }
}
