using System;
using System.Collections.Generic;
using System.Text;
using System.Collections.ObjectModel;

namespace DomainObjects
{
    public class Exam
    {
        private int _id;
        private string _title;
        private IList<Question> _questions = new List<Question>(); 

        public int Id
        {
            get { return _id; } 
        }

        public string Title
        {
            get { return _title; }
            set { _title = value; } 
        }

        public void AddQuestion(Question question)
        {
            if (_questions.Contains(question)) return;

            _questions.Add(question);

            question.Exam = this; 
        }

        public IList<Question> Questions
        {
            get { return new ReadOnlyCollection<Question>(_questions); }           
        }
    }
}
