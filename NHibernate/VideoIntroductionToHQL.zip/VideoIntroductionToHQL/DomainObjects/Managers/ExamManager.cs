using System;
using System.Collections.Generic;
using System.Text;
using NHibernate;

namespace DomainObjects.Managers
{
    public sealed class ExamManager : DomainManager<Exam>
    {
       
    }
}
