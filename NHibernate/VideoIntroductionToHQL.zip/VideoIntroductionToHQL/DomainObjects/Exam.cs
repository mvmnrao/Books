using System;
using System.Collections.Generic;
using System.Text;
using System.Collections.ObjectModel;

namespace DomainObjects
{
    public class Exam : DomainBase
    {
        
        private string _title;
                       
        private IList<Question>  _questions = new List<Question>(); 
            

        public string Title
        {
            get { return _title; }
            set { _title = value; } 
        }

        public void AddQuestion(Question question)
        {
            if (_questions.Contains(question)) return;

            _questions.Add(question);

            question.Exam = this; 
        }

        public double TotalPoint
        {
            get
            {
                double sum = 0.0;
                IEnumerator<Question> enumerator =  _questions.GetEnumerator();
                while (enumerator.MoveNext())
                {
                    sum += enumerator.Current.Point; 
                }
                
                return sum; 
            }
        }
      
        public IList<Question> Questions
        {
            get { return new ReadOnlyCollection<Question>(_questions); }           
        }

        protected override bool IsValid
        {
            get
            {
                return (_questions.Count > 0); 
            }
            set
            {
                base.IsValid = value;
            }
        }
    }
}
