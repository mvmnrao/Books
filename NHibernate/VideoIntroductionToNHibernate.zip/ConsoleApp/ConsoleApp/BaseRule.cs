using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp
{
    public class BaseRule
    {
    }
}
