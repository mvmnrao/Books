using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using NHibernate;
using DomainObjects.Entities;


namespace ConsoleApp
{
    class Program
    {
        static void Main(string[] args)
        {
            
        }
    
    }
}
